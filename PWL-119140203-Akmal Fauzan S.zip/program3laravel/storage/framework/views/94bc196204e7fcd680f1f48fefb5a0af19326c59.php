<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table, td, th {  
          border: 1px solid #ddd;
          text-align: left;
        }

        table {
          border-collapse: collapse;
        }

        th, td {
          padding: 15px;
        }
        .prodi{
            height: 100%;
            border: none;
            outline:none;
            cursor: pointer;
            padding: 20px;
            font-family: sans-serif;
            font-size: 18px;
            background-color: rgb(255, 255, 255);
	        color: #1baedb;
        }
    </style>
</head>
<body>
    <input type="text" id="jmlData">
    <br>
    <br>
    <select name="tahun" id="tahun">
        <option value=0>--</option>
        <option value="ganjil">Ganjil</option>
        <option value="genap">Genap</option>
    </select>


    <button type="submit" onclick="tampilDalamProdi()">Tampilkan</button>

    <div id="tabelData">
        <input type="text" id="search">
        <button class="prodi" onclick="tampilDalamProdi()">Dalam Prodi</button>
        <button class="prodi" onclick="tampilLuarProdi()">Luar Prodi</button>
        <select name="jmlData" id="jmlData" onchange="rowData(value)">
            <option value=10>10</option>
            <option value=20>20</option>
            <option value=30>30</option>
        </select>
        <table>
            <thead>
                <th>Kode Kelas</th>
                <th>Nama Kelas</th>
                <th>Kode Matakuliah</th>
                <th>Nama Mata kuliah</th>
                <th>SKS</th>
            </thead>
            <tbody id="dataTabel">
            </tbody>
        </table>
    </div>

    <div class="pageNumbers" id="pagination"></div>
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    var arrayJsonDalam;
var arrayJsonLuar;

var paginationsItem = document.getElementById('pagination');
var tabelData = document.getElementById("tabelData");
let currentPage = 1;
let perHalaman = 10;
var dataTabel = document.getElementById("dataTabel");
var searchForm = document.getElementById("search");
var cekPosisi = [];
var tahun = document.getElementById("tahun");



tabelData.style.visibility = "hidden"
$.ajax({
    url: '/showDalam',
    type: 'GET',
    dataType: 'json',
    success: function(data){  
        arrayJsonDalam = data
    }
});
$.ajax({
    url: '/showLuar',
    type: 'GET',
    dataType: 'json',
    success: function(data){  
        arrayJsonLuar = data
    }
});

searchForm.addEventListener('change',queryProcess);

function queryProcess(query){
    var hasilSearchDalam = [];
    var hasilSearchLuar = [];
    console.log(query.target.value)
    for(var i=0; i<arrayJsonDalam.length; i++){
        if(arrayJsonDalam[i].kode_kelas == query.target.value || arrayJsonDalam[i].kelas == query.target.value || arrayJsonDalam[i].kode == query.target.value || arrayJsonDalam[i].nama_mata_kuliah == query.target.value || arrayJsonDalam[i].sks == query.target.value){
            hasilSearchDalam.push(arrayJsonDalam[i])
        }
    }

    for(var i=0; i<arrayJsonLuar.length; i++){
        if(arrayJsonLuar[i].kode_kelas == query.target.value || arrayJsonLuar[i].kelas == query.target.value || arrayJsonLuar[i].kode == query.target.value || arrayJsonLuar[i].nama_mata_kuliah == query.target.value || arrayJsonLuar[i].sks == query.target.value){
            hasilSearchLuar.push(arrayJsonLuar[i])
        }
    }

    if(hasilSearchDalam.length > 0 && cekPosisi[cekPosisi.length-1]==0){
        dalamProdi(hasilSearchDalam, dataTabel, perHalaman, currentPage);
    }

    if(hasilSearchLuar.length >0 && cekPosisi[cekPosisi.length-1]==1){
        luarProdi(hasilSearchLuar, dataTabel, perHalaman, currentPage);
    }

    if(hasilSearchLuar == 0 && hasilSearchDalam == 0){
        dataTabel.innerHTML = "";
        alert("data tidak ada");
    }

}


function tampilDalamProdi(){
    tabelData.style.visibility = "visible";
    // displayList(arrayJsonDalam, dataTabel, perHalaman, currentPage);
    var cond = 1;
    dalamProdi(arrayJsonDalam, dataTabel, perHalaman, currentPage)
    setUpPagination(arrayJsonDalam, paginationsItem, perHalaman,cond);
}

function tampilLuarProdi(){
    var cond = 0;
    luarProdi(arrayJsonLuar, dataTabel, perHalaman, currentPage);
    setUpPagination(arrayJsonLuar, paginationsItem, perHalaman, cond)
}


function dalamProdi(dataMatkul, templateData, perHalaman, hal){
    cekPosisi.push(0)
    templateData.innerHTML=""
    hal--;
    var arrayFixedTahunDalam = [];
    for(var i=0; i<dataMatkul.length; i++){
        if(dataMatkul[i].semester ===tahun.value){
            arrayFixedTahunDalam.push(dataMatkul[i]);
        }
    }
    console.log(arrayFixedTahunDalam)

    let start = perHalaman*hal;
    console.log(start)
    let end = start + perHalaman;
    console.log(end)
    let paginatedItems = arrayFixedTahunDalam.slice(start,end)
    // console.log(paginatedItems)
    
    for(var i=0; i<paginatedItems.length; i++){
        // if(paginatedItems[i].semester === tahun.value){
        var tRow = document.createElement("tr");
        var kodeKelas = document.createElement("td");
        var namaKelas = document.createElement("td");
        var kodeMatkul = document.createElement("td");
        var namaMatkul = document.createElement("td");
        var sks = document.createElement("td");
        kodeKelas.appendChild(document.createTextNode(paginatedItems[i].kode_kelas));
        namaKelas.appendChild(document.createTextNode(paginatedItems[i].kelas));
        kodeMatkul.appendChild(document.createTextNode(paginatedItems[i].kode));
        namaMatkul.appendChild(document.createTextNode(paginatedItems[i].nama_mata_kuliah));
        sks.appendChild(document.createTextNode(paginatedItems[i].sks));
        tRow.appendChild(kodeKelas);
        tRow.appendChild(namaKelas);
        tRow.appendChild(kodeMatkul);
        tRow.appendChild(namaMatkul);
        tRow.appendChild(sks);
        templateData.appendChild(tRow);
        // }
    }
}

function luarProdi(dataMatkul, templateData, perHalaman, hal){
    cekPosisi.push(1)
    templateData.innerHTML=""
    hal--;

    var arrayFixedTahunLuar = [];
    var tahun = document.getElementById("tahun");
    for(var i=0; i<dataMatkul.length; i++){
        if(dataMatkul[i].semester ===tahun.value){
            arrayFixedTahunLuar.push(dataMatkul[i]);
        }
    }
    console.log(arrayFixedTahunLuar)

    let start = perHalaman*hal;
    console.log(start)
    let end = start + perHalaman;
    console.log(end)
    let paginatedItems = arrayFixedTahunLuar.slice(start,end)

    for(var i=0; i<paginatedItems.length; i++){
            var tRow = document.createElement("tr");
            var kodeKelas = document.createElement("td");
            var namaKelas = document.createElement("td");
            var kodeMatkul = document.createElement("td");
            var namaMatkul = document.createElement("td");
            var sks = document.createElement("td");
            kodeKelas.appendChild(document.createTextNode(paginatedItems[i].kode_kelas));
            namaKelas.appendChild(document.createTextNode(paginatedItems[i].kelas));
            kodeMatkul.appendChild(document.createTextNode(paginatedItems[i].kode));
            namaMatkul.appendChild(document.createTextNode(paginatedItems[i].nama_mata_kuliah));
            sks.appendChild(document.createTextNode(paginatedItems[i].sks));
            tRow.appendChild(kodeKelas);
            tRow.appendChild(namaKelas);
            tRow.appendChild(kodeMatkul);
            tRow.appendChild(namaMatkul);
            tRow.appendChild(sks);
            dataTabel.appendChild(tRow);
    }
}

function setUpPagination(items, dataTabel, rowPerPage,cond){
    dataTabel.innerHTML="";

    let hitungHalaman = Math.ceil(items.length / rowPerPage);
    for(var i=1; i<hitungHalaman+1; i++){
        let btn = paginationButton(i, items,cond);
        dataTabel.appendChild(btn);
    }
}

function paginationButton(page, items, cond){
    let button = document.createElement('button');
    button.innerText = page;

    if(currentPage == page){
        button.classList.add('active')
    }

    button.addEventListener('click', function(){
        currentPage = page;
        if(cond == 1){
            dalamProdi(items, dataTabel, perHalaman, currentPage);
        }else{
            luarProdi(items, dataTabel, perHalaman, currentPage)
        }

        let currentBtn = document.querySelector('.pageNumbers button.active');
        currentBtn.classList.remove('active');

        button.classList.add('active');
    })
    return button;
}

function rowData(jmlData){
    // var jmlData = document.getElementById("#jmlData").value;
    var tahunCek = document.getElementById("tahun");
    console.log(jmlData," ",tahunCek.value)
    if(tahunCek.value == "ganjil"){
        // alert(jmlData)
        if(jmlData == 10){
            console.log("tes")
            dalamProdi(arrayJsonDalam, dataTabel, jmlData, currentPage);
        }else if(jmlData == 20){
            dalamProdi(arrayJsonDalam, dataTabel, jmlData, currentPage);
        }else if(jmlData == 30){
            dalamProdi(arrayJsonDalam, dataTabel, jmlData, currentPage);
        }
    }else if(tahunCek.value == "genap"){
        // alert(jmlData);
        if(jmlData == 10){
            luarProdi(arrayJsonLuar, dataTabel, jmlData, currentPage)
        }else if(jmlData == 20){
            luarProdi(arrayJsonLuar, dataTabel, jmlData, currentPage)
        }else if(jmlData == 30){
            luarProdi(arrayJsonLuar, dataTabel, jmlData, currentPage)
        }
    }
}

</script>
</body>
</html>


<?php /**PATH D:\xampp\htdocs\dashboard\PWL\UTS\program3\resources\views/index.blade.php ENDPATH**/ ?>